import micropython
import uasyncio as asyncio
from machine import UART
class CommunicationProtocol:
    # Configuration
    HEADER = b'\x41\x5A' #"415A" #b'415A'
    FOOTER = b'\x59\x42' #"5942" #b'5942'

    # Shared state
    rx_buffer = bytearray(10)
    CRITICAL_FLAG = False
    MOTOR_CHANGE = False
    INFO_FLAG = False
    MOTOR_SPEED = 0
    MOTOR_DIRECTION = 0
    MOTOR_ID = 0
    CODE = 0
    uart = None


    def __init__(self): 
        # Initialize UART and IRQ
        CommunicationProtocol.uart = UART(2, baudrate=9600, tx=8, rx=18) # esp32 s3
        #CommunicationProtocol.uart = UART(2, baudrate=9600, tx=17, rx=16)
        #updates for asyncho
        CommunicationProtocol.swriter = asyncio.StreamWriter(CommunicationProtocol.uart, {})
        CommunicationProtocol.sreader = asyncio.StreamReader(CommunicationProtocol.uart)
        CommunicationProtocol.rx_buffer = bytearray()

        CommunicationProtocol.CRITICAL_FLAG = False
        CommunicationProtocol.MOTOR_CHANGE = False
        CommunicationProtocol.INFO_FLAG = False
        CommunicationProtocol.MOTOR_SPEED = 0
        CommunicationProtocol.MOTOR_DIRECTION = 0
        CommunicationProtocol.MOTOR_ID = 0
        #CommunicationProtocol.uart.irq(handler=self.uart_callback, trigger=UART.RX_ANY)
    
    async def listen(self):

        while True:
            if CommunicationProtocol.uart.any():
                data = CommunicationProtocol.uart.read(32)
                if data:
                    CommunicationProtocol.rx_buffer += data.decode('utf-8', 'ignore')
                    print(f"recieved packet checking it")
                await self._parse_buffer()
            await asyncio.sleep_ms(10)  # Small delay to prevent CPU hogging
                

    async def _parse_buffer(self):
        
        while (len(self.rx_buffer) > 0) :
            start = CommunicationProtocol.rx_buffer.find(CommunicationProtocol.HEADER)
            if start == -1:
                # No header? Keep last 4 bytes in case header is splitting
                if len(CommunicationProtocol.rx_buffer) > 10:
                    CommunicationProtocol.rx_buffer = CommunicationProtocol.rx_buffer[-4:]
                break

            if start > 0:
                # Junk before header, remove it
                CommunicationProtocol.rx_buffer = CommunicationProtocol.rx_buffer[start:]

            end = CommunicationProtocol.rx_buffer.find(CommunicationProtocol.FOOTER)
            end_idx = end + len(CommunicationProtocol.FOOTER)

            if end != -1 and end < start or end == 1:
                break
            if end == -1:
                break #need more data for full packet
            else :
                full_packet = CommunicationProtocol.rx_buffer[:end_idx]
                CommunicationProtocol.rx_buffer =  CommunicationProtocol.rx_buffer[end_idx:]
                print(f"Valid Packet Received. Payload: {full_packet}")

            await self.process_packet(full_packet)
            await asyncio.sleep_ms(20)

    async def process_packet(self, packet):
        CommunicationProtocol.CRITICAL_FLAG, CommunicationProtocol.MOTOR_CHANGE, CommunicationProtocol.INFO_FLAG, CommunicationProtocol.MOTOR_SPEED, CommunicationProtocol.MOTOR_DIRECTION, CommunicationProtocol.MOTOR_ID, CommunicationProtocol.CODE

        
        payload = packet[2:-2] # removes first and last 2 bytes
        
        #payload = payload.decode('ascii') # i think this will pull it back down?    
        
        print(f"Payload: {payload}")
        print(f"Payload length: {len(payload)}")
        if len(payload) < 2:
            return
        if(payload[1] == ord('4')) :      # Could be a massive choke point though
            # I now have to care
            CommunicationProtocol.CRITICAL_FLAG = True
        
            if len(payload) >= 6 and payload[2] == ord('1'):
                # Handle 6-byte style
                # going based off of end size in case I need to change message type OR add in new cases
                CommunicationProtocol.MOTOR_CHANGE = True
                CommunicationProtocol.MOTOR_ID = int(chr(payload[3]))
                upperMotor = 0
                lowerMotor = int(chr(payload[4]))
                CommunicationProtocol.MOTOR_DIRECTION = int(chr(payload[5]))
                speed = upperMotor*16 + lowerMotor
                if (speed == 16) :
                    speed = 0
                CommunicationProtocol.MOTOR_SPEED = speed

                print(f"Motor ID: {CommunicationProtocol.MOTOR_ID}, Speed: {CommunicationProtocol.MOTOR_SPEED}, Direction: {CommunicationProtocol.MOTOR_DIRECTION}")
                
            elif (payload[0] == ord('12')) :
                # Handle 3-byte style
                CommunicationProtocol.INFO_FLAG = True
                CommunicationProtocol.CODE = int(chr(payload[len(payload)-1]))
                print(f"Code: {CommunicationProtocol.CODE}")
        elif payload[0] == 4 :
            #Do nada
            print(f"Packet from me not Forwarding again")
        else:            # Not for me, pass it along
            print(f"Packet not for me, forwarding: {packet}")
            CommunicationProtocol.uart.write(packet)
        


    def uart_callback(t): # Gemini aided
        if t.any():
            newData = t.read()
            CommunicationProtocol.rx_buffer += newData
            
            # 1. Clean up "junk" data: if the buffer doesn't start with HEADER, 
            # find the first occurrence of HEADER and delete everything before it.
            start_idx = CommunicationProtocol.rx_buffer.find(CommunicationProtocol.HEADER)
            if start_idx > 0:
                CommunicationProtocol.rx_buffer = CommunicationProtocol.rx_buffer[start_idx:]
                # Refresh start_idx after deletion
                start_idx = 0 
                
            # 2. Check for FOOTER
            footer_idx = CommunicationProtocol.rx_buffer.find(CommunicationProtocol.FOOTER)
            if start_idx != -1 and footer_idx != -1:
                end_idx = footer_idx + len(CommunicationProtocol.FOOTER)
               
                if end_idx > start_idx:
                    full_packet = CommunicationProtocol.rx_buffer[start_idx:end_idx]
                    CommunicationProtocol.rx_buffer = CommunicationProtocol.rx_buffer[end_idx:] # Clear this packet from buffer
                    
                    # 3. Use != for value comparison
                    # Assuming index 5 is "address" byte

                    if full_packet[5] != b'4': 
                        # Not for me: Pass it along
                        print(f"Uart Callback: Packet not for me, forwarding: {full_packet}")
                        CommunicationProtocol.uart.write(full_packet)
                    else:
                        # For me: Process it
                        print(f"Uart Callback: Valid Packet Received. Payload: {full_packet}")
                        micropython.schedule(self.process_packet, full_packet)
            CommunicationProtocol.rx_buffer = bytearray()

    async def send_Motor_Info(self, id, speedUp, speedDown, dir):
        packet = [
            [CommunicationProtocol.HEADER], #header
            ["4"],  # from me
            ["1"],  # to Sam
            ["2"],  # message type
            ["2"], # to adrian again till removed from team site
            [id],
            [speedUp],
            [speedDown],
            [dir],
            [CommunicationProtocol.FOOTER] # footer
        ]
        CommunicationProtocol.uart.write(packet)
    
    async def send_Error(self, code):
        packet = [
            [CommunicationProtocol.HEADER], #header
            ["4"], # from me
            ["1"], # to Sam
            ["A"], # message type
            ["2"], # to adrian again till removed from team site
            [code],
            ["4"],
            [CommunicationProtocol.FOOTER] # footer
        ]
        CommunicationProtocol.uart.write(packet)

    async def send_Status(self, code):
        packet = [
            [CommunicationProtocol.HEADER], #header
            ["4"], # from me
            ["1"], # to Sam
            ["D"], # message type
            ["2"], #subsystem number again
            ["4"], # my number again
            [code],
            [CommunicationProtocol.FOOTER] # footer
        ]
        CommunicationProtocol.uart.write(packet)

    



