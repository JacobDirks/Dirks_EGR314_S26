import uasyncio as asyncio
from machine import Pin, SPI
import time

class MotorController:
    
    SUCCESS = 0
    INVALID_MOTOR = 1
    INVALID_STATE = 2
    INVALID_SPI = 3

    FWD = bytes([0b11101111]) # 11101111
    REV = bytes([0b11101101]) # 11101101
    STOP = bytes([0b11101110]) # 11101110 I think should work 
    #following Page 14 of data so I think it's 
    # bit 5-7 - Wrt_ctrl (111), 
    # bit 4 - Open load source disconnect (0) [kinda req], 
    # bit 3 - Sin [required] (1) for SPI, 
    # bit 2 - SEN (1) Enable SPI outputs,
    # bit 1 - SDIR (1) [can change], 
    # bit 0 - SPWM (1) in case of spi control [currently testing stop]
    
        # esp 32s3
    MOTORDRIVER = SPI(
        2, #mode
        baudrate=9600,
        polarity=0,
        phase=1,
        sck=Pin(12), #d18
        mosi=Pin(13), #d23
        miso=Pin(8) #d19
    #gemini had me switch mosi and miso so we should see that work
    )
    #SPI Mode 1 - Falling edge when clock is low --> Polarity=0 & Phase=1
    # Chip Select pin

    #Esp-32 s3 (sfm) pins
    csPins = [47, 21, 14]
    csPinsObjects = [Pin(47, Pin.OUT, value=1),
               Pin(21, Pin.OUT, value=1), 
               Pin(14, Pin.OUT, value=1)] #note this should be 47
    '''
    #esp32 - dev kit pins
    spi = SPI(
        2, #mode
        baudrate=9600,
        polarity=0,
        phase=1,
        sck=Pin(18), #d18
        mosi=Pin(23), #d23
        miso=Pin(27) #d19 #Garbage line
    )
    cs_pins = [33, 22, 21]
    csPinsObjects = [
        Pin(33, Pin.OUT, value=1), #garbage line
        Pin(22, Pin.OUT, value=1),
        Pin(21, Pin.OUT, value=1)
        ]
    '''
    pinState = [STOP, STOP, STOP]


    async def commonRun():
        if MotorController.MOTORDRIVER is None: 
            return MotorController.INVALID_SPI
            
        for i in range(len(MotorController.csPins)):
            pin = MotorController.csPinsObjects[i]
            state = MotorController.pinState[i]
            
            pin.value(0) # Select
            time.sleep_us(10)

            MotorController.MOTORDRIVER.write(state)
            time.sleep_us(10)

            pin.value(1) # Deselect
        await asyncio.sleep_ms(1)
            

    def __init__(spi_bus, cs_pin_objects, cs_pins):
        MotorController.MOTORDRIVER = spi_bus
        MotorController.csPinsObjects = cs_pin_objects # pin objects
        MotorController.csPins = cs_pins # integers
        # Initialize all motors to STOP state
        MotorController.pinState = [self.STOP for _ in range(len(MotorController.csPins))]

        for pin in self.csPinsObjects:
            pin.value(1) # Ensure deselected


    def setState(motor_index, category):
        # motor_index should be 0, 1, or 2
        
        if not (0 <= motor_index < len(MotorController.csPinsObjects)):
            return MotorController.INVALID_MOTOR #Return invalid motor before checking
        

        if category == 0:                   #Can't use match case as it might be implemented in the needed python
            MotorController.pinState[motor_index] = MotorController.STOP
        elif category == 1:
            MotorController.pinState[motor_index] = MotorController.FWD
        elif category == -1:
            MotorController.pinState[motor_index] = MotorController.REV
        else:
            return MotorController.INVALID_STATE
        
        return MotorController.SUCCESS


    def stop_all():
        for i in range(len(MotorController.pinState)):
            MotorController.pinState[i] = MotorController.STOP
            #time.sleep(1) # insanely long
        MotorController.commonRun()