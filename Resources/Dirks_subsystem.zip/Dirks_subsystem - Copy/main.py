import uasyncio as asyncio

from machine import SPI, Pin, UART
import time
from MotorController import MotorController
from CommunicationProtocol import CommunicationProtocol

#=========================================================

# SETUP SPI connection 
#---------------------------------------------------------

print("Starting Init...")
proto = CommunicationProtocol()
print("Proto Init Done")
#motor_system = MotorController(spi, my_pins, cs_pins)
print("Motor System Init Done")


#errorSignal = Pin(32, mode=Pin.IN, pull=Pin.PULL_DOWN)
# Pin(2,Pin.OUT, value = 1)

#=========================================================
#Write main code
#---------------------------------------------------------

async def main():

    print("Starting asynchio")
    try:
        await asyncio.gather(
            proto.listen(),
            motor_logic_task()
        )
    except Exception as e:
        print("CRASH DETECTED:", e)
        # Give you time to read it before the WDT kicks in
        time.sleep(5)

async def motor_logic_task():
    while True:
        if CommunicationProtocol.MOTOR_CHANGE:
            #led.value(1)
            direction = CommunicationProtocol.MOTOR_DIRECTION
                        # Logic for speed/direction
            if CommunicationProtocol.MOTOR_SPEED == 0:
                direction = 0
            elif direction == 0:
                direction = -1


            print(f"id: {CommunicationProtocol.MOTOR_ID}, speed: {CommunicationProtocol.MOTOR_SPEED}, dir: {direction}")
            MotorController.setState(1, direction) #was based on motor id originally
            MotorController.setState(2, direction)
            
            # Push the new state to the hardware immediately
            await MotorController.commonRun()
            
            CommunicationProtocol.MOTOR_CHANGE = False
            #led.value(0)
        
        # This prevents the WDT reset by yielding control to the scheduler
        await asyncio.sleep_ms(10)
        
        
time.sleep(2)
print(f"We're running so far...")
try:
    asyncio.run(main())
except KeyboardInterrupt:
    print(f"Program stopped by user")

