import time
import uasyncio as asyncio
from machine import SPI, Pin
from MotorController import MotorController

async def test_sequence():

    print("Verification loop starting...")
    
    try:
        while True:
            # Testing Forward
            print("Action: Forward")
            MotorController.setState(0, 1)
            MotorController.setState(1, 1)
            MotorController.setState(2, 1)
            await MotorController.commonRun() # Now properly awaited
            await asyncio.sleep(2)

            # Testing Stop
            print("Action: Stop")
            MotorController.stop_all() # Ensure stop_all() in MotorController.py is NOT async, 
                                       # OR add 'await' here if you made it async.
            await asyncio.sleep(2)

            # Testing Reverse
            print("Action: Reverse")
            MotorController.setState(0, -1)
            MotorController.setState(1, -1)
            MotorController.setState(2, -1)
            await MotorController.commonRun()
            await asyncio.sleep(2)
            
            MotorController.stop_all()
            await asyncio.sleep(2)
            
    except KeyboardInterrupt:
        print("Test stopped by user.")
        MotorController.stop_all()

# Run the wrapper
if __name__ == "__main__":
    try:
        asyncio.run(test_sequence())
    except Exception as e:
        print(f"Loop Crash: {e}")