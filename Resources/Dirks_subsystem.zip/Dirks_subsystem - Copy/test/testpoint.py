from machine import Pin
import time

class Testpoint:
    pin1 = Pin(14, Pin.OUT)
    while(True):
        print(f'looping')
        pin1.value(1)
        time.sleep(5)
        pin1.value(0)
        time.sleep(5)
        