from machine import UART

class UartTest:
    
     uart = UART(2, baudrate=9600, tx=8, rx=18)
     while(True):
         test = uart.read()
         
         if test:
             print(f'{test}')