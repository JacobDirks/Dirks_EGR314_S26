import time
from machine import Pin, UART

# 1. Initialize UART 
# IMPORTANT: Ensure this matches your Subsystem baudrate (was 9600 in your last class file)
uart = UART(2, baudrate=9600, tx=17, rx=16)

# 2. Global variable for Debouncing
last_interrupt_time = 0

def send_packet(msg, label):
    """
    Handles the logic for debouncing and sending UART data.
    Using ticks_ms() prevents the '8 blue messages' bug.
    """
    global last_interrupt_time
    current_time = time.ticks_ms()
    
    # Only allow a press every 300ms
    if time.ticks_diff(current_time, last_interrupt_time) > 300:
        #msg = bytes.fromhex(msg)  # Convert hex string to bytes
        uart.write(msg.encode())
        print(f"[{label}] Sent: {msg}")
        last_interrupt_time = current_time

# 3. Define ISR Handlers (Keep them lightning fast!)
def button_blue_handler(pin):
    # Request status - Subsystem 4
    send_packet('415A024C435942', "STATUS_REQ")

def button_green_handler(pin):
    # Speed Set - Subsystem 4
    send_packet('415A241414415942', "SPEED_SET")

def button_orange_handler(pin):
    # Bypass Test - Targeted at Subsystem 3 (Sub 4 should forward this)
    send_packet('415A231314415942', "BYPASS_TEST")

# 4. Pin Setup
# PIN 19 moved to 32 to avoid SPI MISO conflict on the other ESP32
pin_blue = Pin(4, Pin.IN, Pin.PULL_DOWN) 
pin_green = Pin(5, Pin.IN, Pin.PULL_DOWN) 
pin_orange = Pin(22, Pin.IN, Pin.PULL_DOWN)

# 5. Attach Interrupts
pin_blue.irq(trigger=Pin.IRQ_RISING, handler=button_blue_handler)
pin_green.irq(trigger=Pin.IRQ_RISING, handler=button_green_handler)
pin_orange.irq(trigger=Pin.IRQ_RISING, handler=button_orange_handler)

print("Master Controller Ready.")
print("Baudrate: 9600 | Logic: Async Debounce")

# 6. Monitor the Ring for Responses
while True:
    if uart.any():
        try:
            # Read and clean up the incoming data
            raw_data = uart.read()
            # Try to decode, otherwise show hex
            try:
                decoded = raw_data.decode('utf-8').strip()
                print(f"RING_BACK: {decoded}")
            except:
                print(f"RING_BACK (Hex): {raw_data.hex()}")
        except Exception as e:
            print(f"Error reading UART: {e}")
            
    time.sleep_ms(10)